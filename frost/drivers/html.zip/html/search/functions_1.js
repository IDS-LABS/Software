var searchData=
[
  ['setfreq',['setFreq',['../classH__Driver__CORE_1_1PCA9865.html#a746e1e3746dec4f182484e4dddeea50a',1,'H_Driver_CORE::PCA9865']]]
];
